package com.example.lostfound;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class Create extends AppCompatActivity {

    private RadioButton lost,found;
    private EditText nameEditText, contactEditText, descriptionEditText, locationEditText;
    private TextView dateEditText;
    private Button saveButton;
    private Calendar calendar;
    int position = -1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);

        // Initialize calendar instance
        calendar = Calendar.getInstance();

        // Initialize views
        nameEditText = findViewById(R.id.name);
        contactEditText = findViewById(R.id.contact);
        descriptionEditText = findViewById(R.id.description);
        dateEditText = findViewById(R.id.date);
        locationEditText = findViewById(R.id.location);
        saveButton = findViewById(R.id.save);
        lost = findViewById(R.id.lost);
        found = findViewById(R.id.found);

        dateEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePicker();
            }
        });
        lost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                position = 0;
                found.setChecked(false);
            }
        });
        found.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                position = 1;
                lost.setChecked(false);
            }
        });

        // Save button click listener
        saveButton.setOnClickListener(view -> {
            try {
                savePost();
                navigateToAnotherActivity(CreateOrView.class);
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        });
    }
    private void showDatePicker() {
        // Create DatePickerDialog and set initial date to current date
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, dateSetListener,
                calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }

    // DatePickerDialog.OnDateSetListener to handle the selected date
    private DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            // Update calendar instance with selected date
            calendar.set(Calendar.YEAR, year);
            calendar.set(Calendar.MONTH, monthOfYear);
            calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

            // Update EditText text with selected date
            updateDateEditText();
        }
        private void updateDateEditText() {
            String myFormat = "dd/MM/yyyy"; // Date format
            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.getDefault());
            dateEditText.setText(sdf.format(calendar.getTime()));
        }
    };
    private void savePost() throws SQLException {

        OrmliteHelper ormliteHelper = new OrmliteHelper(this);
        PostDTO postDTO             = new PostDTO();

        // Get input values
        String name = nameEditText.getText().toString();
        String contact = contactEditText.getText().toString();
        String description = descriptionEditText.getText().toString();
        String date = dateEditText.getText().toString();
        String location = locationEditText.getText().toString();


        // Perform validation
        if (name.isEmpty() || contact.isEmpty() || description.isEmpty() || date.isEmpty() || location.isEmpty() || position == -1) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }
        postDTO.setName(name);
        postDTO.setContact(contact);
        postDTO.setDescription(description);
        postDTO.setLocation(location);
        postDTO.setDate(date);
        if(position == 0) {
            postDTO.setLost(true);
        } else if (position == 1) {
            postDTO.setLost(false);
        }
        ormliteHelper.createOrUpdate(postDTO);
        Toast.makeText(this, "Post Successfully Added", Toast.LENGTH_SHORT).show();
    }
    private void navigateToAnotherActivity(Class<?> destinationActivity) {
        Intent intent = new Intent(this, destinationActivity);
        startActivity(intent);
    }
}
